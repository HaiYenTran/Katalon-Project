import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

'PREPARE DATA'
def userName = CustomKeywords.'com.kms.cms.MyKeyword.getRandomUser'()
def fullName = userName + '_fullName'
def email = userName + '@gmail.com'
def passWord = 'BiNouLunM3UiJsgMQbjdfQ=='
def confirmPass = passWord
def invalidLogin = 'Either login or password is invalid.'
def status = 'Active'
int currentTab = WebUI.getWindowIndex()

'Step 1: Navigate to CMS Home page'
'VP: Brought to Home page'
 WebUI.verifyMatch(WebUI.getWindowTitle(),GlobalVariable.HOME_TITLE,false, FailureHandling.CONTINUE_ON_FAILURE)

 
'Step 2: Follow steps in TC#1 to create a new user' 
WebUI.click(findTestObject('Object Repository/HomePage/lnk_SignUp'), FailureHandling.STOP_ON_FAILURE)
WebUI.callTestCase(TestCaseFactory.findTestCase('Test Cases/CommonTestcase/CreateNewUser'), [('userName'):userName, ('fullName'):fullName,
	 ('email'):email, ('gender'):GlobalVariable.GENDER_MALE, ('passWord'):passWord, ('confirmPass'):confirmPass ] , FailureHandling.STOP_ON_FAILURE)


'Step 3: Click on "Log In" menu'
WebUI.click(findTestObject('Object Repository/HomePage/lnk_LogIn'), FailureHandling.STOP_ON_FAILURE)
'VP: Brought to Login page'
WebUI.verifyMatch(WebUI.getWindowTitle(), GlobalVariable.LOGIN_TITLE, false, FailureHandling.CONTINUE_ON_FAILURE)


'Step 4: Log in with newly created user'
WebUI.callTestCase(TestCaseFactory.findTestCase('Test Cases/CommonTestcase/LoginSystem'), [('user'):userName, ('pass'):passWord], FailureHandling.STOP_ON_FAILURE)
'VP:User is still in Log In page'
WebUI.verifyMatch(WebUI.getWindowTitle(), 'Login :: Powered by Subrion 4.2', false, FailureHandling.CONTINUE_ON_FAILURE)


'Step 5: Verify error message is displayed: “Either login or password is invalid.”  '
WebUI.verifyTextPresent("Either login or password is invalid.",false, FailureHandling.CONTINUE_ON_FAILURE)


'Step 6: Login Admin page'
'VP: Clear data in User textbox'
WebUI.clearText(findTestObject('Object Repository/LoginPage/txt_Username'), FailureHandling.STOP_ON_FAILURE)
WebUI.callTestCase(TestCaseFactory.findTestCase('Test Cases/CommonTestcase/LoginSystem'), [('user'):GlobalVariable.ADMIN_USER, ('pass'): GlobalVariable.PASSWORD], FailureHandling.STOP_ON_FAILURE)
'VP: Brought to My Profile page'
WebUI.verifyMatch(WebUI.getWindowTitle(), GlobalVariable.MY_PROFILE_TITLE,false, FailureHandling.CONTINUE_ON_FAILURE)


'Step 7: Navigate to Administration Panel page '
WebUI.click(findTestObject('Object Repository/AdminPage/btn_AdminDashboard'), FailureHandling.STOP_ON_FAILURE)
WebUI.switchToWindowUrl(GlobalVariable.URL_ADMIN, FailureHandling.STOP_ON_FAILURE)
'VP: Brought to Dashboard page'
WebUI.waitForPageLoad(GlobalVariable.MEDIUM_TIME_OUT)
WebUI.verifyMatch(WebUI.getWindowTitle(), GlobalVariable.DASHBOARD_TITLE, false,FailureHandling.CONTINUE_ON_FAILURE)


'Step 8: Click on "Member" menu of main menu'
WebUI.delay(GlobalVariable.SHORT_TIME_OUT)
WebUI.click(findTestObject('Object Repository/AdminPage/lnk_Members'), FailureHandling.STOP_ON_FAILURE)


'Step 9: Click on " Member" menu on Sub menu'
WebUI.click(findTestObject('Object Repository/AdminPage/lnk_subMember'), FailureHandling.STOP_ON_FAILURE)


'Step 10: Click on Edit icon of created member'
WebUI.waitForElementVisible(findTestObject('Object Repository/MemberPage/txt_Search'), GlobalVariable.SHORT_TIME_OUT)
WebUI.setText(findTestObject('MemberPage/txt_Search'), userName, FailureHandling.STOP_ON_FAILURE)
WebUI.click(findTestObject('MemberPage/btn_Search'), FailureHandling.STOP_ON_FAILURE)
WebUI.delay(GlobalVariable.SHORT_TIME_OUT)
WebUI.click(findTestObject('MemberPage/chk_user'), FailureHandling.STOP_ON_FAILURE)
WebUI.click(findTestObject('Object Repository/AdminPage/btn_Edit'), FailureHandling.STOP_ON_FAILURE)
'VP: Brought to Edit Member page'
WebUI.verifyMatch(WebUI.getWindowTitle(), GlobalVariable.EDIT_MEMBER_TITLE, false, FailureHandling.CONTINUE_ON_FAILURE)


'Step 11: Select "Active" status'
WebUI.selectOptionByLabel(findTestObject('Object Repository/EditMemberPage/ddl_Status'),status, false,FailureHandling.STOP_ON_FAILURE)


'Step 12: Click on "Save" button'
WebUI.click(findTestObject('Object Repository/EditMemberPage/btn_Save'), FailureHandling.STOP_ON_FAILURE)
'Brought to Members page'
WebUI.waitForPageLoad(GlobalVariable.MEDIUM_TIME_OUT)


'Step 13: Log out of the system'
WebUI.delay(GlobalVariable.SHORT_TIME_OUT)
WebUI.click(findTestObject('Object Repository/MemberPage/btn_Logout'), FailureHandling.STOP_ON_FAILURE)


'Step 14: Navigate to Home Page'
WebUI.click(findTestObject('Object Repository/AdminPage/btn_BackToHomePage'), FailureHandling.STOP_ON_FAILURE)


'Step 15: Click on "Log In" menu'
WebUI.click(findTestObject('Object Repository/HomePage/lnk_LogIn'), FailureHandling.STOP_ON_FAILURE)


'Step 16: Log in with activated user'
WebUI.callTestCase(TestCaseFactory.findTestCase('Test Cases/CommonTestcase/LoginSystem'), [('user'):userName, ('pass'):passWord], FailureHandling.STOP_ON_FAILURE)
'Brought to Home Page, username is displayed in the menu bar'
WebUI.verifyMatch(WebUI.getWindowTitle(),GlobalVariable.HOME_TITLE,false, FailureHandling.CONTINUE_ON_FAILURE)
WebUI.verifyMatch(WebUI.getAttribute((findTestObject('Object Repository/HomePage/img_User')),'title'),fullName, false, FailureHandling.CONTINUE_ON_FAILURE)


