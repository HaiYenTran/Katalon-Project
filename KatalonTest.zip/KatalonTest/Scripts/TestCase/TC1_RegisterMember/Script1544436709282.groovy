import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

'PREPARE DATA'
def userName = CustomKeywords.'com.kms.cms.MyKeyword.getRandomUser'()
def fullName = userName + '_fullName'
def email = userName + '@gmail.com'
def passWord = 'BiNouLunM3UiJsgMQbjdfQ=='
def confirmPass = passWord

'Step 1: Navigate to CMS Home page'
'VP: Brought to Home page'
 WebUI.verifyMatch(WebUI.getWindowTitle(),GlobalVariable.HOME_TITLE, false, FailureHandling.STOP_ON_FAILURE)

 
'Step 2: Click on "Sign Up" link in Main Menu'
WebUI.click(findTestObject('Object Repository/HomePage/lnk_SignUp'), FailureHandling.STOP_ON_FAILURE)


'Step 3: Register a Member '
WebUI.callTestCase(TestCaseFactory.findTestCase('Test Cases/CommonTestcase/CreateNewUser'), [('userName'):userName, ('fullName'):fullName,
	 ('email'):email, ('gender'):GlobalVariable.GENDER_MALE, ('passWord'):passWord, ('confirmPass'):confirmPass ] , FailureHandling.STOP_ON_FAILURE)
'VP: Brought to Registration page'
WebUI.verifyMatch(WebUI.getWindowTitle(), GlobalVariable.REGISTRATION_TITLE, false, FailureHandling.STOP_ON_FAILURE)


'Step 4: Verify the successful message "Member registered! Thank you!" is displayed correctly'
WebUI.verifyTextPresent('Member registered! Thank you!', false,FailureHandling.CONTINUE_ON_FAILURE)


'Step 5: Verify the registration email is displayed in the information message'
WebUI.verifyTextPresent(email, false, FailureHandling.CONTINUE_ON_FAILURE)

'CLEAN UP'
WebUI.callTestCase(TestCaseFactory.findTestCase('Test Cases/CommonTestcase/DeleteUser'), [('user'):userName], FailureHandling.OPTIONAL)
