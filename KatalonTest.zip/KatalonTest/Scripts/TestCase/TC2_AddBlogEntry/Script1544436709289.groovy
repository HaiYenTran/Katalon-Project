import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

'PREPARE'
def header = '[' + CustomKeywords.'com.kms.cms.MyKeyword.getCurrentDateTime'() + ']' + ' U23 Vietnam won U23 Irag'
def body = 'U23 Vietnam went to the final match with U23 Uzbekistan'
def tag = 'football'
def blogEntryTitle = header + ' :: Powered by Subrion 4.2'

//Use an existing valid user for this test case, e.g. katalontest/katalontest@2018

'Step 1: Log in to System'
'VP: Login to the System'
WebUI.click(findTestObject('Object Repository/HomePage/lnk_LogIn'), FailureHandling.STOP_ON_FAILURE)
WebUI.callTestCase(TestCaseFactory.findTestCase('Test Cases/CommonTestcase/LoginSystem'), [('user'):GlobalVariable.USER, ('pass'):GlobalVariable.PASS], FailureHandling.STOP_ON_FAILURE)


'Step 2: Click on "Blog" menu'
WebUI.click(findTestObject('Object Repository/HomePage/lnk_Blog'), FailureHandling.STOP_ON_FAILURE)
 

'Step 3: Add blog'
WebUI.callTestCase(TestCaseFactory.findTestCase('Test Cases/CommonTestcase/AddBlogEntry'), [('header'):header, ('body'):body, ('tag'):tag ], FailureHandling.STOP_ON_FAILURE)
'VP: Brought to "Blog Entry" page'
WebUI.verifyMatch(WebUI.getWindowTitle(), blogEntryTitle,false, FailureHandling.CONTINUE_ON_FAILURE)


'Step 4: Verify the "Blog Entry" page'
'VP: Verify the title, the content, the tags are displayed correctly'
WebUI.verifyMatch(WebUI.getText(findTestObject('Object Repository/AdminPage/dat_header')),header, false,FailureHandling.CONTINUE_ON_FAILURE)
WebUI.verifyMatch(WebUI.getText(findTestObject('Object Repository/AdminPage/dat_contentBody')),body,false, FailureHandling.CONTINUE_ON_FAILURE)
WebUI.verifyMatch(WebUI.getText(findTestObject('Object Repository/AdminPage/dat_Tag')),tag, false,FailureHandling.CONTINUE_ON_FAILURE)


