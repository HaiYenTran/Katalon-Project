import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable


'Step 1: Navigate to Admin page'
WebUI.navigateToUrl(GlobalVariable.URL_ADMIN, FailureHandling.OPTIONAL)
WebUI.maximizeWindow()

'Step 2: Login Admin page'
WebUI.callTestCase(TestCaseFactory.findTestCase('Test Cases/CommonTestcase/LogintoAdminPage'), [('adminUser'):GlobalVariable.ADMIN_USER, ('passAdmin'): GlobalVariable.PASSWORD], FailureHandling.OPTIONAL)
'Verify Admin page available'
WebUI.waitForPageLoad(GlobalVariable.MEDIUM_TIME_OUT)


'Step 3: Click on "Member" menu of main menu'
WebUI.delay(GlobalVariable.SHORT_TIME_OUT)
WebUI.waitForElementClickable(findTestObject('Object Repository/AdminPage/lnk_Members'), GlobalVariable.SHORT_TIME_OUT, FailureHandling.OPTIONAL)
WebUI.click(findTestObject('Object Repository/AdminPage/lnk_Members'), FailureHandling.OPTIONAL)


'Step 4: Click on " Member" menu on Sub menu'
WebUI.click(findTestObject('Object Repository/AdminPage/lnk_subMember'), FailureHandling.OPTIONAL)


'Step 5: Click on "Delete" icon of created member'
WebUI.waitForElementVisible(findTestObject('Object Repository/MemberPage/txt_Search'), GlobalVariable.SHORT_TIME_OUT, FailureHandling.OPTIONAL)
WebUI.setText(findTestObject('Object Repository/MemberPage/txt_Search'), user, FailureHandling.OPTIONAL)
WebUI.click(findTestObject('Object Repository/MemberPage/btn_Search'), FailureHandling.OPTIONAL)
WebUI.delay(GlobalVariable.SHORT_TIME_OUT)
WebUI.click(findTestObject('Object Repository/MemberPage/chk_user'), FailureHandling.OPTIONAL)
WebUI.click(findTestObject('Object Repository/MemberPage/btn_Remove'), FailureHandling.OPTIONAL)

'Step 6: Select Yes to delete the user'
WebUI.click(findTestObject('Object Repository/MemberPage/btn_YesConfirm'), FailureHandling.OPTIONAL)

