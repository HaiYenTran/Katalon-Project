import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

'Click on "Add Blog Entry" button'
WebUI.click(findTestObject('Object Repository/AddBlogPage/btn_AddBlogEntry'), FailureHandling.STOP_ON_FAILURE)

'Input value into "Title" field'
WebUI.setText(findTestObject('Object Repository/AddBlogPage/txt_Title'), header, FailureHandling.STOP_ON_FAILURE)

'Input value into "Body" field'
WebUI.switchToFrame(findTestObject('Object Repository/AddBlogPage/fra_Iframe'), 30, FailureHandling.STOP_ON_FAILURE)
WebUI.setText(findTestObject('Object Repository/AddBlogPage/txt_body'), body, FailureHandling.STOP_ON_FAILURE)
WebUI.switchToDefaultContent()

'Input value into "Tags"  field'
WebUI.setText(findTestObject('Object Repository/AddBlogPage/txt_Tag'), tag, FailureHandling.CONTINUE_ON_FAILURE)

'Click on "Save" button'
WebUI.click(findTestObject('Object Repository/AddBlogPage/btn_Save'),FailureHandling.STOP_ON_FAILURE)
WebUI.waitForPageLoad((GlobalVariable.SHORT_TIME_OUT))