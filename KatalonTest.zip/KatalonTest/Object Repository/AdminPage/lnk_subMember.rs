<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnk_subMember</name>
   <tag></tag>
   <elementGuidId>083313eb-7e1a-4ae8-9c5d-93f58ef8d3cb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='nav-sub-members']//a[text()[normalize-space(.) = 'Members']]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
