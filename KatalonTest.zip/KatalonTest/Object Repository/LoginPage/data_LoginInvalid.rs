<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>data_LoginInvalid</name>
   <tag></tag>
   <elementGuidId>1b4bd05a-df91-4b0b-8713-ffe3b624fc06</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[contains(@class, 'page-system')]//li[text()[normalize-space(.) ='Either login or password is invalid.']]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
