<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_body</name>
   <tag></tag>
   <elementGuidId>0e096042-ca5c-4445-a07a-5fa9b5636263</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//html/body[contains(@class, 'cke_editable cke_editable_themed cke_contents_ltr cke_show_borders')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
