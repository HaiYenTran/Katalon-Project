<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TestSuites_1</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-12-14T17:13:45</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>f1e0af20-f2eb-46fc-b5ac-2115fcb061ed</testSuiteGuid>
   <testCaseLink>
      <guid>77bce233-8b18-4197-a849-f5e0d2ff2406</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TestCase/TC2_AddBlogEntry</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>41f0e339-93f6-4d83-9862-2c9c4c2f14cd</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TestCase/TC3_OnlyActiveMemberCanLoginToSystem</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>4dcfc530-44b1-496e-af85-a3da834be893</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TestCase/TC1_RegisterMember</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
