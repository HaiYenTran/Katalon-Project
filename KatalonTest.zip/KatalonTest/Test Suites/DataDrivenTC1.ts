<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>DataDrivenTC1</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-11-29T14:59:43</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>52fe1b21-52cb-49ba-9e26-393baac80f4f</testSuiteGuid>
   <testCaseLink>
      <guid>c0f3ba24-ce0e-4986-abf5-512abcecc8aa</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/DataDrivenTestCase/TC1_DataDiven_RegisterMember</testCaseId>
      <testDataLink>
         <combinationType>MANY</combinationType>
         <id>56ce6368-f021-4ad7-83f3-3eca6a3ff56e</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/DataFile</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>56ce6368-f021-4ad7-83f3-3eca6a3ff56e</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>User Name</value>
         <variableId>dddd0d6c-2e81-4fb0-b78a-a5193eb12d13</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>56ce6368-f021-4ad7-83f3-3eca6a3ff56e</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Full Name</value>
         <variableId>2d079f7e-c42f-4cf1-aa8d-bb7e730e6852</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>56ce6368-f021-4ad7-83f3-3eca6a3ff56e</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Email</value>
         <variableId>fc465aa7-60e1-4e05-87d7-07987cb7e351</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>56ce6368-f021-4ad7-83f3-3eca6a3ff56e</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Password</value>
         <variableId>a32dba00-b2f1-425c-b168-4769c3be867a</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>56ce6368-f021-4ad7-83f3-3eca6a3ff56e</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Confirm Password</value>
         <variableId>4ce3bab8-8acd-434e-8e78-376a20017cfd</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>56ce6368-f021-4ad7-83f3-3eca6a3ff56e</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Gender</value>
         <variableId>2ccd8fc8-0612-47ce-be39-dcf06f6bc2ec</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
