
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */


def static "com.kms.cms.MyKeyword.getCurrentDateTime"() {
    (new com.kms.cms.MyKeyword()).getCurrentDateTime()
}

def static "com.kms.cms.MyKeyword.getRandomUser"() {
    (new com.kms.cms.MyKeyword()).getRandomUser()
}

def static "com.kms.cms.MyKeyword.killChromeDriver"() {
    (new com.kms.cms.MyKeyword()).killChromeDriver()
}
