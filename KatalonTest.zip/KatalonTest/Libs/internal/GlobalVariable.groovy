package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase

/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p>Profile default : Global URL</p>
     */
    public static Object URL_CMSHOME
     
    /**
     * <p></p>
     */
    public static Object ADMIN_USER
     
    /**
     * <p></p>
     */
    public static Object PASSWORD
     
    /**
     * <p>Profile default : The longest waiting time</p>
     */
    public static Object LONG_TIME_OUT
     
    /**
     * <p>Profile default : The medium waiting time</p>
     */
    public static Object MEDIUM_TIME_OUT
     
    /**
     * <p>Profile default : The short waiting time</p>
     */
    public static Object SHORT_TIME_OUT
     
    /**
     * <p></p>
     */
    public static Object GENDER_MALE
     
    /**
     * <p></p>
     */
    public static Object GENDER_FEMALE
     
    /**
     * <p></p>
     */
    public static Object URL_ADMIN
     
    /**
     * <p></p>
     */
    public static Object USER
     
    /**
     * <p></p>
     */
    public static Object PASS
     
    /**
     * <p></p>
     */
    public static Object HOME_TITLE
     
    /**
     * <p></p>
     */
    public static Object DASHBOARD_TITLE
     
    /**
     * <p></p>
     */
    public static Object REGISTRATION_TITLE
     
    /**
     * <p></p>
     */
    public static Object ADD_BLOG_ENTRY_TITLE
     
    /**
     * <p></p>
     */
    public static Object LOGIN_TITLE
     
    /**
     * <p></p>
     */
    public static Object MY_PROFILE_TITLE
     
    /**
     * <p></p>
     */
    public static Object EDIT_MEMBER_TITLE
     
    /**
     * <p></p>
     */
    public static Object MEMBER_TITLE
     

    static {
        def allVariables = [:]        
        allVariables.put('default', ['URL_CMSHOME' : 'http://13.250.134.32/subrion/', 'ADMIN_USER' : 'admin', 'PASSWORD' : 'HWHXedaqLCcdweoNIlpVpw==', 'LONG_TIME_OUT' : 90, 'MEDIUM_TIME_OUT' : 30, 'SHORT_TIME_OUT' : 10, 'GENDER_MALE' : 'Male', 'GENDER_FEMALE' : 'Female', 'URL_ADMIN' : 'http://13.250.134.32/subrion/panel/', 'USER' : 'katalontest', 'PASS' : '/qFNx0rqStfhIctz8RlA+3C1jmyuRhXb', 'HOME_TITLE' : 'Home :: Powered by Subrion 4.2', 'DASHBOARD_TITLE' : 'Dashboard :: Powered by Subrion 4.2', 'REGISTRATION_TITLE' : 'Registration :: Powered by Subrion 4.2', 'ADD_BLOG_ENTRY_TITLE' : 'Add Blog Entry :: Powered by Subrion 4.2', 'LOGIN_TITLE' : 'Login :: Powered by Subrion 4.2', 'MY_PROFILE_TITLE' : 'My Profile :: Powered by Subrion 4.2', 'EDIT_MEMBER_TITLE' : 'Edit Member :: Powered by Subrion 4.2', 'MEMBER_TITLE' : 'Members :: Powered by Subrion 4.2'])
        
        String profileName = RunConfiguration.getExecutionProfile()
        
        def selectedVariables = allVariables[profileName]
        URL_CMSHOME = selectedVariables['URL_CMSHOME']
        ADMIN_USER = selectedVariables['ADMIN_USER']
        PASSWORD = selectedVariables['PASSWORD']
        LONG_TIME_OUT = selectedVariables['LONG_TIME_OUT']
        MEDIUM_TIME_OUT = selectedVariables['MEDIUM_TIME_OUT']
        SHORT_TIME_OUT = selectedVariables['SHORT_TIME_OUT']
        GENDER_MALE = selectedVariables['GENDER_MALE']
        GENDER_FEMALE = selectedVariables['GENDER_FEMALE']
        URL_ADMIN = selectedVariables['URL_ADMIN']
        USER = selectedVariables['USER']
        PASS = selectedVariables['PASS']
        HOME_TITLE = selectedVariables['HOME_TITLE']
        DASHBOARD_TITLE = selectedVariables['DASHBOARD_TITLE']
        REGISTRATION_TITLE = selectedVariables['REGISTRATION_TITLE']
        ADD_BLOG_ENTRY_TITLE = selectedVariables['ADD_BLOG_ENTRY_TITLE']
        LOGIN_TITLE = selectedVariables['LOGIN_TITLE']
        MY_PROFILE_TITLE = selectedVariables['MY_PROFILE_TITLE']
        EDIT_MEMBER_TITLE = selectedVariables['EDIT_MEMBER_TITLE']
        MEMBER_TITLE = selectedVariables['MEMBER_TITLE']
        
    }
}
